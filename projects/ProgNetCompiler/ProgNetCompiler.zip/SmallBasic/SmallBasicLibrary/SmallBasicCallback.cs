﻿using System;

namespace Microsoft.SmallBasic.Library
{
   public delegate void SmallBasicCallback();
}