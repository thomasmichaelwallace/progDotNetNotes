﻿using System;

namespace Microsoft.SmallBasic.Library
{
   public class SmallBasicTypeAttribute : Attribute
   {
      public SmallBasicTypeAttribute()
      {
      }
   }
}