﻿using System;

namespace Microsoft.SmallBasic.Library
{
   public class HideFromIntellisenseAttribute : Attribute
   {
      public HideFromIntellisenseAttribute()
      {
      }
   }
}